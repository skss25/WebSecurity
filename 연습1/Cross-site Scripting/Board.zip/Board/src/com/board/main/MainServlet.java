package com.board.main;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.controller.BoardController;
import com.board.controller.CreateBoardControllerImpl;
import com.board.controller.DeleteBoardControllerImpl;
import com.board.controller.ReadBoardControllerImpl;
import com.board.controller.ShowBoardControllerImpl;
import com.board.controller.UpdateBoardControllerImpl;

@WebServlet("/")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Map<String, BoardController> hashMap = null;
    
    @Override
	public void init(ServletConfig config) throws ServletException {
		hashMap = new HashMap<String,BoardController>();
		hashMap.put("/show", new ShowBoardControllerImpl());
		hashMap.put("/create", new CreateBoardControllerImpl());
		hashMap.put("/read", new ReadBoardControllerImpl());
		hashMap.put("/update", new UpdateBoardControllerImpl());
		hashMap.put("/delete", new DeleteBoardControllerImpl());
	}


	public MainServlet() {
        super();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String uri = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = uri.substring(contextPath.length());
		BoardController boardController = hashMap.get(path);
		boardController.service(request, response);
	}

}
