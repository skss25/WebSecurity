package com.board.dto;

public class Content {
	private String id;
	private String title;
	private String register;
	private String regDate;
	private String text;
	
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getRegister() {
		return register;
	}


	public void setRegister(String register) {
		this.register = register;
	}


	public String getRegDate() {
		return regDate;
	}


	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}


	@Override
	public String toString() {
		return "Content [id=" + id + ", title=" + title + ", register=" + register + ", regDate=" + regDate + ", text="
				+ text + "]";
	}
	
	
}
