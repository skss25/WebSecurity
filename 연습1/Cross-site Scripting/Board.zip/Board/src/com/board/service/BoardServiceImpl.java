package com.board.service;

import java.util.List;

import com.board.dao.BoardDao;
import com.board.dao.BoardDaoImpl;
import com.board.dto.Content;

public class BoardServiceImpl implements BoardService {
	BoardDao bDao = null;

	public BoardServiceImpl() {
		this.bDao = new BoardDaoImpl();
	}

	@Override
	public List<Content> showAll() {
		return bDao.showAll();
	}

	@Override
	public int create(Content cnt) {
		return bDao.create(cnt);
	}

	@Override
	public Content read(Content cnt) {
		return bDao.read(cnt);
	}

	@Override
	public int update(Content cnt) {
		return bDao.update(cnt);
	}

	@Override
	public int delete(Content cnt) {
		return bDao.delete(cnt);
	}

}
