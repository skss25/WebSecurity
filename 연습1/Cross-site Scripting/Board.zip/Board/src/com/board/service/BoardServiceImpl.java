package com.board.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.board.dao.BoardDao;
import com.board.dao.BoardDaoImpl;
import com.board.dto.Content;
import com.nhncorp.lucy.security.xss.XssFilter;

public class BoardServiceImpl implements BoardService {
	private BoardDao bDao = null;

	public BoardServiceImpl() {
		this.bDao = new BoardDaoImpl();
	}

	@Override
	public List<Content> showAll(HttpServletRequest req) {
		List<Content> list = bDao.showAll();
		if(list != null) { 
			req.setAttribute("list", list); 
		}else {
			req.setAttribute("list", new ArrayList<Content>());
		}
		
		return list;
	}

	@Override
	public int create(HttpServletRequest req) {
		
		Content cnt = new Content();
		cnt.setTitle(req.getParameter("title"));
		cnt.setRegister(req.getParameter("register"));
		cnt.setText(req.getParameter("text"));
		
		return bDao.create(cnt);
	}

	@Override
	public Content read(HttpServletRequest req) {
		Content cnt = new Content();
		cnt.setId(req.getParameter("id"));
		
		return bDao.read(cnt);
	}

	@Override
	public int update(HttpServletRequest req) {
		Content cnt = new Content();
		return bDao.update(cnt);
	}

	@Override
	public int delete(HttpServletRequest req) {
		Content cnt = new Content();
		return bDao.delete(cnt);
	}

}
