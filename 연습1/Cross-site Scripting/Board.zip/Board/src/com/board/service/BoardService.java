package com.board.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.board.dto.Content;

public interface BoardService {
	public List<Content> showAll(HttpServletRequest req); //��� �Խù� ��ȸ
	public int create(HttpServletRequest req); //�Խù��� ����
	public Content read(HttpServletRequest req);
	public int update(HttpServletRequest req);
	public int delete(HttpServletRequest req);
}
