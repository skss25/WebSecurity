package com.board.service;

import java.util.List;

import com.board.dto.Content;

public interface BoardService {
	public List<Content> showAll(); //��� �Խù� ��ȸ
	public int create(Content cnt); //�Խù��� ����
	public Content read(Content cnt);
	public int update(Content cnt);
	public int delete(Content cnt);
}
