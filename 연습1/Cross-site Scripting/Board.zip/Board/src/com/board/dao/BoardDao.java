package com.board.dao;

import java.util.List;

import com.board.dto.Content;

public interface BoardDao {
	/*
	 * ����
	 * http://www.h2database.com/html/main.html
	 * https://www.tutorialspoint.com/h2_database/h2_database_jdbc_connection.htm
	 * http://www.h2database.com/html/datatypes.html
	 * https://dev.mysql.com/doc/refman/8.0/en/date-and-time-functions.html
	 */
	public String JDBC_DRIVER = "org.h2.Driver";
	public String DB_URL = "jdbc:h2:~/test";
	public String USER = "sa";
	public String PASS = "";
	
	public List<Content> showAll(); //��� �Խù� ��ȸ
	public int create(Content cnt); //�Խù��� ����
	public Content read(Content cnt);
	public int update(Content cnt);
	public int delete(Content cnt);
}
