package com.board.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.board.dto.Content;

public class BoardDaoImpl implements BoardDao {

	@Override
	public List<Content> showAll() {
		/*
		 * ���ǿ� ��ϵ� ����Ʈ�� �о�´�.
		 * */
		Content con = null;
		List<Content> ls = new ArrayList<Content>();
		ResultSet rs = null;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		String sql = "SELECT * FROM BOARD";
		try(
			Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = conn.createStatement()
		){
			rs = stmt.executeQuery(sql); //������ ����
			while(rs.next()) {
				con = new Content();
				con.setId(rs.getString("id"));
				con.setTitle(rs.getString("title"));
				con.setRegister(rs.getString("register"));
				con.setRegDate(rs.getString("regdate"));
				con.setText(rs.getString("text"));
				
				ls.add(con);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return ls;
	}

	@Override
	public int create(Content cnt) {
		/**************�ߺ��� �ڵ�********************/
		int n = 0;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		String sql = "INSERT INTO Board(id, title, register, regdate, text) VALUES (DEFAULT, ?, ?, NOW(), ?)";
		try(
			Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
			PreparedStatement pstmt = conn.prepareStatement(sql)
		){
			
			pstmt.setString(1, cnt.getTitle());
			pstmt.setString(2, cnt.getRegister());
			pstmt.setString(3, cnt.getText());
			
			n = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return n;
	}

	@Override
	public Content read(Content cnt) {
		
		ResultSet rs = null;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		String sql = "SELECT * FROM BOARD WHERE id = ?";
		try(
			Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
			PreparedStatement pstmt= conn.prepareStatement(sql)
		){
			pstmt.setString(1, cnt.getId());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				cnt.setTitle(rs.getString("title"));
				cnt.setRegister(rs.getString("register"));
				cnt.setRegDate(rs.getString("regdate"));
				cnt.setText(rs.getString("text"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public int update(Content cnt) {
		return 0;
	}

	@Override
	public int delete(Content cnt) {
		return 0;
	}
}
