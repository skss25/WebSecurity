package com.board.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.dto.Content;

public class CreateBoardControllerImpl implements BoardController {
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Content cnt = new Content();
		cnt.setTitle(req.getParameter("title"));
		cnt.setRegister(req.getParameter("register"));
		cnt.setText(req.getParameter("text"));
		boardService.create(cnt);
		
		res.sendRedirect("./show");
	}
}
