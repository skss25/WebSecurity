package com.board.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.dto.Content;

public class ReadBoardControllerImpl implements BoardController {
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setAttribute("text", boardService.read(req)); //�Խù� ����
		
		//�Խù� Ȯ���� ���� �̵�
		RequestDispatcher dr = req.getRequestDispatcher("read.jsp");
		dr.forward(req, res);
	}
}
