package com.board.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.dto.Content;

public class ShowBoardControllerImpl implements BoardController {
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		boardService.showAll(req);
		
		RequestDispatcher dr=req.getRequestDispatcher("/index.jsp");
		dr.forward(req, res);
	}

}
