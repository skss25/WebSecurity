package com.board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.service.BoardService;
import com.board.service.BoardServiceImpl;

public interface BoardController {
	BoardService boardService = new BoardServiceImpl();

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
}
