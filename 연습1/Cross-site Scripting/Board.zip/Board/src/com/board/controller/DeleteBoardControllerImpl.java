package com.board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteBoardControllerImpl implements BoardController {

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("Delete Controller �Դϴ�!");

	}

}
